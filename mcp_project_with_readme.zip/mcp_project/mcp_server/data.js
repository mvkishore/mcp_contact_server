// Sample contact data stored in a simple JSON object
const contactData = {
  "+12025550123": {
    name: "John Smith",
    linkedInProfile: "https://linkedin.com/in/johnsmith",
    email: "john.smith@example.com",
    address: "123 Main St, New York, NY 10001"
  },
  "+14155550189": {
    name: "Sarah Johnson",
    linkedInProfile: "https://linkedin.com/in/sarahjohnson",
    email: "sarah.johnson@example.com",
    address: "456 Market St, San Francisco, CA 94105"
  },
  "+16175550156": {
    name: "Michael Chen",
    linkedInProfile: "https://linkedin.com/in/michaelchen",
    email: "michael.chen@example.com",
    address: "789 Tech Ave, Boston, MA 02115"
  },
  "+19175550178": {
    name: "Emily Davis",
    linkedInProfile: "https://linkedin.com/in/emilydavis",
    email: "emily.davis@example.com",
    address: "321 Park Ave, New York, NY 10022"
  },
  "+13105550192": {
    name: "David Wilson",
    linkedInProfile: "https://linkedin.com/in/davidwilson",
    email: "david.wilson@example.com",
    address: "555 Ocean Blvd, Los Angeles, CA 90024"
  }
};

module.exports = contactData;
