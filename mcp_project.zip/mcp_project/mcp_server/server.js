const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const contactData = require('./data');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    message: 'MCP Contact Information Server',
    endpoints: {
      'GET /api/contact/:phoneNumber': 'Get contact information for a specific phone number',
      'GET /api/contacts': 'Get all available contacts'
    }
  });
});

// Get contact by phone number
app.get('/api/contact/:phoneNumber', (req, res) => {
  const { phoneNumber } = req.params;
  
  if (contactData[phoneNumber]) {
    res.json({
      success: true,
      data: contactData[phoneNumber]
    });
  } else {
    res.status(404).json({
      success: false,
      message: 'Contact not found for the provided phone number'
    });
  }
});

// Get all contacts
app.get('/api/contacts', (req, res) => {
  res.json({
    success: true,
    data: contactData
  });
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`MCP Server running on http://0.0.0.0:${PORT}`);
});
